// Alambre3DView.h : interface of the CAlambre3DView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALAMBRE3DVIEW_H__D6B7A1CC_ABFD_11D2_BEB0_004F4906470A__INCLUDED_)
#define AFX_ALAMBRE3DVIEW_H__D6B7A1CC_ABFD_11D2_BEB0_004F4906470A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

////////////////////////////////////////////////////////////////
//    ESTRUCTURAS
////////////////////////////////////////////////////////////////

// Vertices
struct Vertice
{
	double nX;
	double nY;
	double nZ;
	double nXPantalla;
	double nYPantalla;
	double nZPantalla;
};

// Lineas
struct Linea
{
	Vertice Inicio, Final;
	int nColor;
};


class CAlambre3DView : public CView
{
protected: // create from serialization only
	CAlambre3DView();
	DECLARE_DYNCREATE(CAlambre3DView)

// Attributes
public:
	CAlambre3DDoc* GetDocument();

// Operations
public:
    void Calculo( double MatrizMaestra[4][4] );
	void MultiplicarMatriz( double Resultado[4][4],
						    double Matriz1[4][4],
							double Matriz2[4][4] );
	void MultiplicarVector( double Resultado[4],
						    double Matriz1[4],
							double Matriz2[4][4] );


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlambre3DView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAlambre3DView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAlambre3DView)
	afx_msg void OnRepintar();
	afx_msg void OnPaint();
	afx_msg void OnMasx();
	afx_msg void OnMasy();
	afx_msg void OnMasz();
	afx_msg void OnMenosx();
	afx_msg void OnMenosy();
	afx_msg void OnMenosz();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in Alambre3DView.cpp
inline CAlambre3DDoc* CAlambre3DView::GetDocument()
   { return (CAlambre3DDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALAMBRE3DVIEW_H__D6B7A1CC_ABFD_11D2_BEB0_004F4906470A__INCLUDED_)
