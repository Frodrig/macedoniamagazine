// Alambre3DView.cpp : implementation of the CAlambre3DView class
//

#include "stdafx.h"
#include "afxtempl.h"
#include "Alambre3D.h"

#include "Alambre3DDoc.h"
#include "Alambre3DView.h"

#include "math.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////////////////////////////////////////////////////
// Variables Globales
////////////////////////////////////////////////////////////////
CArray<Linea,Linea>     oLineas;      // Lineas del dibujo
double GradosX = 0, GradosY = 0, GradosZ = 0;

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DView

IMPLEMENT_DYNCREATE(CAlambre3DView, CView)

BEGIN_MESSAGE_MAP(CAlambre3DView, CView)
	//{{AFX_MSG_MAP(CAlambre3DView)
	ON_COMMAND(ID_REPINTAR, OnRepintar)
	ON_WM_PAINT()
	ON_COMMAND(ID_MASX, OnMasx)
	ON_COMMAND(ID_MASY, OnMasy)
	ON_COMMAND(ID_MASZ, OnMasz)
	ON_COMMAND(ID_MENOSX, OnMenosx)
	ON_COMMAND(ID_MENOSY, OnMenosy)
	ON_COMMAND(ID_MENOSZ, OnMenosz)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DView construction/destruction

CAlambre3DView::CAlambre3DView()
{
	// TODO: add construction code here

}

CAlambre3DView::~CAlambre3DView()
{
}

BOOL CAlambre3DView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DView drawing

void CAlambre3DView::OnDraw(CDC* pDC)
{
	CAlambre3DDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here

}

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DView diagnostics

#ifdef _DEBUG
void CAlambre3DView::AssertValid() const
{
	CView::AssertValid();
}

void CAlambre3DView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CAlambre3DDoc* CAlambre3DView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CAlambre3DDoc)));
	return (CAlambre3DDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DView message handlers

void CAlambre3DView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
    Linea oLin;

	GradosX = 0;
	GradosY = 0;
	GradosZ = 0;

	// Delante
	// Linea 1
	oLin.Inicio.nX = -50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = -50; oLin.Final.nY  = 50; oLin.Final.nZ  = 0;
	oLineas.Add( oLin );
	// Linea 2
	oLin.Inicio.nX = -50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 0; oLin.Final.nY  = 0; oLin.Final.nZ  = 0;
	oLineas.Add( oLin );
	// Linea 3
	oLin.Inicio.nX = 0; oLin.Inicio.nY = 0; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 50; oLin.Final.nY  = -50; oLin.Final.nZ  = 0;
	oLineas.Add( oLin );
	// Linea 4
	oLin.Inicio.nX = 50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 50; oLin.Final.nY  = 50; oLin.Final.nZ  = 0;
	oLineas.Add( oLin );

	// Atras
	// Linea 1
	oLin.Inicio.nX = -50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 20;
	oLin.Final.nX  = -50; oLin.Final.nY  = 50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Linea 2
	oLin.Inicio.nX = -50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 20;
	oLin.Final.nX  = 0; oLin.Final.nY  = 0; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Linea 3
	oLin.Inicio.nX = 0; oLin.Inicio.nY = 0; oLin.Inicio.nZ = 20;
	oLin.Final.nX  = 50; oLin.Final.nY  = -50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Linea 4
	oLin.Inicio.nX = 50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 20;
	oLin.Final.nX  = 50; oLin.Final.nY  = 50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );

	// Vertices
	// Vertice 1
	oLin.Inicio.nX = -50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = -50; oLin.Final.nY  = -50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Vertice 2
	oLin.Inicio.nX = -50; oLin.Inicio.nY = 50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = -50; oLin.Final.nY  = 50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Vertice 3
	oLin.Inicio.nX = 0; oLin.Inicio.nY = 0; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 0; oLin.Final.nY  = 0; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Vertice 4
	oLin.Inicio.nX = 50; oLin.Inicio.nY = -50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 50; oLin.Final.nY  = -50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	// Vertice 5
	oLin.Inicio.nX = 50; oLin.Inicio.nY = 50; oLin.Inicio.nZ = 0;
	oLin.Final.nX  = 50; oLin.Final.nY  = 50; oLin.Final.nZ  = 20;
	oLineas.Add( oLin );
	
}

void CAlambre3DView::OnRepintar() 
{
	Linea oLin;
	int i;
	double MatrizMaestra[4][4];
	double Vector[4];
	double Resultado[4];

	Calculo( MatrizMaestra );
	for( i = 0; i <= oLineas.GetUpperBound() ; i++ )
	{
		TRACE( "Calculando %d ", i );
		oLin = oLineas.GetAt( i );

		Vector[0] = oLin.Inicio.nX;
		Vector[1] = oLin.Inicio.nY;
		Vector[2] = oLin.Inicio.nZ;
		Vector[3] = 1;
		MultiplicarVector( Resultado, Vector, MatrizMaestra );
		oLin.Inicio.nXPantalla = Resultado[0];
		oLin.Inicio.nYPantalla = Resultado[1];
		oLin.Inicio.nZPantalla = Resultado[2];

		Vector[0] = oLin.Final.nX;
		Vector[1] = oLin.Final.nY;
		Vector[2] = oLin.Final.nZ;
		Vector[3] = 1;
		MultiplicarVector( Resultado, Vector, MatrizMaestra );
		oLin.Final.nXPantalla = Resultado[0];
		oLin.Final.nYPantalla = Resultado[1];
		oLin.Final.nZPantalla = Resultado[2];

		TRACE( " %d %d %d a %d %d %d \n", oLin.Inicio.nXPantalla,
										  oLin.Inicio.nYPantalla,
										  oLin.Inicio.nZPantalla,
										  oLin.Final.nXPantalla,
										  oLin.Final.nYPantalla,
										  oLin.Final.nZPantalla );
		oLineas.SetAt(i,oLin);
	}

	Invalidate( TRUE );	
}

void CAlambre3DView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	Linea oLin;
	int i;

	i = 0;

	for( i = 0; i <= oLineas.GetUpperBound() ; i++ )
	{
		oLin = oLineas.GetAt( i );
		dc.MoveTo( 100+(int) oLin.Inicio.nXPantalla, 100+(int) oLin.Inicio.nYPantalla );
		dc.LineTo( 100+(int) oLin.Final.nXPantalla,  100+(int) oLin.Final.nYPantalla );
	}

	// Do not call CView::OnPaint() for painting messages
}

void CAlambre3DView::Calculo( double MatrizMaestra[4][4] ) 
{
	double MatrizIden[4][4] = { 1,0,0,0,
								0,1,0,0,
								0,0,1,0,
								0,0,0,1 };
	double MatrizZ[4][4] = { cos(GradosZ), sin(GradosZ), 0, 0,
							 -sin(GradosZ), cos(GradosZ), 0, 0,
							 0, 0, 1, 0,
							 0, 0, 0, 1	};
	double MatrizX[4][4] = { 1, 0, 0, 0,
							 0, cos(GradosX), sin(GradosX), 0,
							 0, -sin(GradosX), cos(GradosX), 0,
							 0, 0, 0, 1	};
	double MatrizY[4][4] = { cos(GradosY), 0, -sin(GradosY), 0, 
							 0, 1, 0, 0,
							 sin(GradosY), 0, cos(GradosY), 0, 
							 0, 0, 0, 1	};

	double MatrizAux[4][4];
	double MatrizAux2[4][4];

	MultiplicarMatriz( MatrizAux, MatrizIden, MatrizX );
	MultiplicarMatriz( MatrizAux2, MatrizAux, MatrizY );
	MultiplicarMatriz( MatrizMaestra, MatrizAux2, MatrizZ );

}

void CAlambre3DView::MultiplicarMatriz( double Resultado[4][4],
									    double Matriz1[4][4],
										double Matriz2[4][4] )
{
	for( int i=0; i < 4 ; i++ )
	{
		for( int j=0; j < 4 ; j++)
		{
			Resultado[i][j] = 0;
			for( int k=0; k<4 ; k++ )
				Resultado[i][j] += Matriz1[i][k] * Matriz2[k][j];
		}
	}
}

void CAlambre3DView::MultiplicarVector( double Resultado[4],
									    double Matriz1[4],
										double Matriz2[4][4] )
{
	Resultado[0] = Matriz1[0]*Matriz2[0][0] +
			       Matriz1[1]*Matriz2[0][1] +
   				   Matriz1[2]*Matriz2[0][2] +
				   Matriz1[3]*Matriz2[0][3];
	Resultado[1] = Matriz1[0]*Matriz2[1][0] +
				   Matriz1[1]*Matriz2[1][1] +
				   Matriz1[2]*Matriz2[1][2] +
				   Matriz1[3]*Matriz2[1][3];
	Resultado[2] = Matriz1[0]*Matriz2[2][0] +
				   Matriz1[1]*Matriz2[2][1] +
				   Matriz1[2]*Matriz2[2][2] +
				   Matriz1[3]*Matriz2[2][3];
	Resultado[3] = Matriz1[0]*Matriz2[3][0] +
				   Matriz1[1]*Matriz2[3][1] +
				   Matriz1[2]*Matriz2[3][2] +
				   Matriz1[3]*Matriz2[3][3];
}

void CAlambre3DView::OnMasx() 
{
	// TODO: Add your command handler code here
	GradosX += 0.1;
	OnRepintar();
	
}

void CAlambre3DView::OnMasy() 
{
	// TODO: Add your command handler code here
	GradosY += 0.1;
	OnRepintar();
	
}

void CAlambre3DView::OnMasz() 
{
	// TODO: Add your command handler code here
	GradosZ += 0.1;
	OnRepintar();
	
}

void CAlambre3DView::OnMenosx() 
{
	// TODO: Add your command handler code here
	GradosX -= 0.1;
	OnRepintar();
	
}

void CAlambre3DView::OnMenosy() 
{
	// TODO: Add your command handler code here
	GradosY -= 0.1;
	OnRepintar();
	
}

void CAlambre3DView::OnMenosz() 
{
	// TODO: Add your command handler code here
	GradosZ -=0.1;
	OnRepintar();
	
}
