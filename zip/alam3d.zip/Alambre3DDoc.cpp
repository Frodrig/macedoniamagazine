// Alambre3DDoc.cpp : implementation of the CAlambre3DDoc class
//

#include "stdafx.h"
#include "Alambre3D.h"

#include "Alambre3DDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DDoc

IMPLEMENT_DYNCREATE(CAlambre3DDoc, CDocument)

BEGIN_MESSAGE_MAP(CAlambre3DDoc, CDocument)
	//{{AFX_MSG_MAP(CAlambre3DDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DDoc construction/destruction

CAlambre3DDoc::CAlambre3DDoc()
{
	// TODO: add one-time construction code here

}

CAlambre3DDoc::~CAlambre3DDoc()
{
}

BOOL CAlambre3DDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CAlambre3DDoc serialization

void CAlambre3DDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DDoc diagnostics

#ifdef _DEBUG
void CAlambre3DDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAlambre3DDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DDoc commands
