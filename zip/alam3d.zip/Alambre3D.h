// Alambre3D.h : main header file for the ALAMBRE3D application
//

#if !defined(AFX_ALAMBRE3D_H__D6B7A1C4_ABFD_11D2_BEB0_004F4906470A__INCLUDED_)
#define AFX_ALAMBRE3D_H__D6B7A1C4_ABFD_11D2_BEB0_004F4906470A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

  

/////////////////////////////////////////////////////////////////////////////
// CAlambre3DApp:
// See Alambre3D.cpp for the implementation of this class
//

class CAlambre3DApp : public CWinApp
{
public:
	CAlambre3DApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAlambre3DApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CAlambre3DApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ALAMBRE3D_H__D6B7A1C4_ABFD_11D2_BEB0_004F4906470A__INCLUDED_)
