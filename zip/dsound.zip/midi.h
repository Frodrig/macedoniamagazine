/*==========================================================================
 *
 *  Copyright (C) 1995-1997 Microsoft Corporation. All Rights Reserved.
 *
 *  File: midi.h
 *
 ***************************************************************************/

#ifndef __MIDI_H
#define __MIDI_H

BOOL PlayMidi(char *sFileName, HWND hwnd);
BOOL PauseMidi();
BOOL ResumeMidi(HWND hwnd);
BOOL StopMidi();
BOOL ReplayMidi(HWND hwnd);

#endif

