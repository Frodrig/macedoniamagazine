/* this code generates the interlaced pattern
to the stencil buffer for stereoscopic masking */

/**
 * void interlace_stencil(int gliWindowWidth, int gliWindowHeight)
 *
 * Este c�digo genera el patron en el stencil buffer. Se define en el stencil buffer
 * un patron compuesto por fondo negro y lineas blancas de forma que quedan linias
 * blancas i negras intercaladas.
 */

#include <GL/glut.h>

void interlace_stencil(int gliWindowWidth, int gliWindowHeight) {
	GLint gliY;

	// Definimos un rect�ngulo de pixeles en la ventana donde la imagen final sera mapeada.
	glViewport(0,0,gliWindowWidth,gliWindowHeight);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity;
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	
	// Crea una matriz para proyectar coordenadas bidimensionales en la pantalla
	// y multiplica la matriz actual por ella
	gluOrtho2D(0.0,gliWindowWidth-1,0.0,gliWindowHeight-1);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
		
	// Activamos el back-buffer
	glDrawBuffer(GL_BACK);

	// Activamos el stencil buffer
	glEnable(GL_STENCIL_TEST);

	// Limpiamos el buffer de stencil. Ahora sera una matriz de ceros.
	glClearStencil(0);
	glClear(GL_STENCIL_BUFFER_BIT);

	// Indicamos como se modifican los datos en el stencil buffer cuando un fragmento passa
	// o falla el test de stencil. En este caso, decimos que substituya el valor por el 
	// de referencia.
	glStencilOp (GL_REPLACE, GL_REPLACE, GL_REPLACE); // colorbuffer is copied to stencil
	
	// Desactivamos el z-buffer
	glDisable(GL_DEPTH_TEST);

	// Indicamos que el test se passa siempre, que le valor de referencia es 1
	// y que la m�scara tambi�n es 1
	glStencilFunc(GL_ALWAYS,1,1); 
	
	// Dibujamos el patr�n en el stencil buffer. Dibujamos lineas blancas.
	
	glColor4f(1,1,1,0);
	for (gliY=0; gliY<gliWindowHeight; gliY+=2)
	{
		glLineWidth(1);
		glBegin(GL_LINES);
			glVertex2f(0,gliY);
			glVertex2f(gliWindowWidth,gliY);
		glEnd();	
	}

	// Definimos que no se pueda volver a tocar el stencil buffer.
	glStencilOp (GL_KEEP, GL_KEEP, GL_KEEP); // disabling changes in stencil buffer

	// Forzamos la salida
	glFlush();
}