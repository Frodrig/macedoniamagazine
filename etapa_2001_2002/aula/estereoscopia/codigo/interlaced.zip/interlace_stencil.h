#ifndef __INTERLACE_STENCIL
	#define __INTERLACE_STENCIL

	#ifdef __cplusplus
		extern "C" {
	#endif

	void interlace_stencil(int gliWindowWidth, int gliWindowHeight);

	#ifdef __cplusplus
		}
	#endif

#endif
