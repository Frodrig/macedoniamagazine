/**
 * void stereoproj(float xmin, float xmax, float ymin, float ymax, 
 * float znear, float zfar, float zzps, float dist, float eye)
 *
 * Rutina para crear i activar la matriz de proyecci�n para un subcampo
 *
 * xmin, xmax, ymin, ymax: el rango de cordenadas en el plano con parallax 0.
 * La proporci�n entre (xmax - mxin) y (ymax - ymin) debe ser igual al aspect
 * ratio de la pantalla.
 * 
 * znear, zfar: las coordenadas z de los planos de corte
 *
 * zzps: la coordenada z del plano con parallax 0
 *
 * dist: la distanci del plano de proyecci�n al plano con parallax 0
 *
 * eye: la mitad de la separaci�n interaxial. Tiene que ser positiva para el
 *
 * subcampo derecho y negativa para el izqierdo.
 */

void stereoproj(float xmin, float xmax, float ymin, float ymax, float znear, float zfar, float zzps, float dist, float eye) {
  
	float xmid, ymid, clip_near, clip_far, top, bottom, left, right, dx, dy, n_over_d;

	// Dimensiones de la proyecci�n
	dx = xmax - xmin;
	dy = ymax - ymin;

	// Centros
	xmid = (xmax + xmin) / 2.0;
	ymid = (ymax + ymin) / 2.0;

	// Calculo de los planos de corte
	clip_near =  dist + zzps - znear;
	clip_far = dist + zzps - zfar;

	n_over_d = clip_near / dist;

	// Calculo de las coordenadas para el frustum
	top = n_over_d * dy / 2.0;
	bottom = -top;
	right = n_over_d * (dx / 2.0 - eye);
	left = n_over_d * (-dx / 2.0 - eye);

	// Activamos la matriz de proyecci�n
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glFrustum(left, right, bottom, top, clip_near, clip_far);
	glTranslatef(-xmid - eye, -ymid, -zzps - dist);
}

