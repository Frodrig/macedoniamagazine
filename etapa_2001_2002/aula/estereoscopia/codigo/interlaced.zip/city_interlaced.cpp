/**
 * city_interlaced: programa de demo d'estereoscopia amb el format line interlaced
 *
 * Consta de tres fitxers:
 *		- city_interlaced.cpp: fitxer principal.
 *		- interlace_stencil.c: fitxer de creaci� del patro en el stencil buffer
 *		- stereoproj.c:	fitxer de creaci� de la perspectiva.
 */

// Include necessaris

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <windows.h>
#include <mmsystem.h>
#include <GL/glut.h>
#include "stereoproj.c"
#include "interlace_stencil.c"


#ifndef M_PI
#define M_PI 3.1415926535
#endif

const float piover180 = 0.0174532925f;
static int WIDTH=640;
static int HEIGHT=480;

GLint texId[3];

float kk = 12.0;
static float v=0.0;
static float alpha=-90.0;


/**
 * void reshape(int width, int height)
 *
 * Callback del reshape. En �l se define el nuevo viewport y se llama a la funci�n
 * interlace_stencil para que construya el patr�n del stencil buffer con las nuevas
 * dimensiones de la pantalla.
 */

void reshape( int width, int height ) {
  WIDTH=width;
  HEIGHT=height;
 
  glViewport(0,0,(GLint)width,(GLint)height);
  interlace_stencil (width,height);
  glMatrixMode(GL_MODELVIEW);
}

/**
 * void cub(float posx, float posy, float posz, float scalex, float scaley, float scalez)
 *
 * Funci�n que dibuja un cubo segun los parametros que le pasamos. Los tres primeros son 
 * los de posici�n y los tres �ltimos los de escala.
 */
 
void cub( float posx, float posy, float posz, float scalex, float scaley, float scalez ) {

	glPushMatrix();
		glScalef(scalex, scaley, scalez);
		glTranslatef(posx, posy, posz);
		glBegin(GL_QUADS);
			glVertex3f(-2.0,-2.0,-2.0);
			glVertex3f(2.0,-2.0,-2.0);
			glVertex3f(2.0,2.0,-2.0);
			glVertex3f(-2.0,2.0,-2.0);

			glVertex3f(2.0,-2.0,-2.0);
			glVertex3f(2.0,2.0,-2.0);
			glVertex3f(2.0,2.0,2.0);
			glVertex3f(2.0,-2.0,2.0);
			

			glVertex3f(-2.0,-2.0,-2.0);
			glVertex3f(2.0,-2.0,-2.0);
			glVertex3f(2.0,-2.0,2.0);
			glVertex3f(-2.0,-2.0,2.0);
		
			glVertex3f(-2.0,-2.0,2.0);
			glVertex3f(2.0,-2.0,2.0);
			glVertex3f(2.0,2.0,2.0);
			glVertex3f(-2.0,2.0,2.0);
		
			glVertex3f(-2.0,-2.0,-2.0);
			glVertex3f(-2.0,2.0,-2.0);
			glVertex3f(-2.0,2.0,2.0);
			glVertex3f(-2.0,-2.0,2.0);
			
			glVertex3f(-2.0,2.0,-2.0);
			glVertex3f(2.0,2.0,-2.0);
			glVertex3f(2.0,2.0,2.0);
			glVertex3f(-2.0,2.0,2.0);

			glEnd();
		glPopMatrix();
}


/**
 * void terra()
 *
 * Funci�n para dibujar el suelo
 */

void terra() {

	glBegin(GL_QUADS);
		glColor3f(0.8, 0.8, 0.8);
		glVertex3f(-150.0, 0.0, -150.0);
		glVertex3f(150.0, 0.0, -150.0);
		glVertex3f(150.0, 0.0, 150.0);
		glVertex3f(-150.0, 0.0, 150.0);
	glEnd();

}


/**
 * void display()
 * Funci�n de repintado . En ella es donde miramos que vale el stencil buffer y
 * activamos una perspectiva u otra.
 */

void display() {

	float viewing_angle=45.0f;
	float near_clip_plane=0.1f;
	float far_clip_plane=100.0f;
	float half_angl_tng=(float)tan((viewing_angle/2.f)*piover180); // suport variable for the recalculation
	float shift=half_angl_tng*near_clip_plane;
	// for stereoscopy
	float dist = 5; // distance from center of projection to zeroplane
	float eye = dist/30;


	// Nos disponemos a pintar el subcampo izquierdo
	// Activamos el back buffer
	glDrawBuffer(GL_BACK);

	// Solo dibujaremos si el valor del pixel en el stencil buffer
	// es diferente a uno.
	glStencilFunc(GL_NOTEQUAL,1,1); // draws if stencil <> 1
 
	// Activamos la proyecci�n que nos conviene

	float aspect = 1.333333;

	stereoproj(-half_angl_tng*dist* aspect,
				half_angl_tng*dist* aspect,
				-half_angl_tng*dist, half_angl_tng*dist,
				-near_clip_plane, -far_clip_plane,
				-dist, dist, -eye);

    // Activamos el z-buffer
	glEnable(GL_DEPTH_TEST);

	// Limpiamos el buffer de color y el z-buffer
	glClearColor(1.0,1.0,1.0,1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Situamos la camara
  	gluLookAt(1.0, .25, 50-v, 1.0 ,.25 ,49-v, 0.0, 1.0, 0.0);

	// Dibujamos el suelo y los 5 cubos
	terra();

    glColor4f(1.0, 0.0, 0.0, 1.0);
	cub(-10.0, 0.5 ,-10.0, 0.25, 0.5, 2.);

	glColor4f(0.0, 1.0, 0.0, 1.0);
	cub(10.0, 0.5 ,-10.0, 0.25, 0.5, 2.);

	glColor4f(0.0, 0.0, 1.0, 1.0);
	cub(-10.0, 0.5 ,20.0, 0.25, 0.5, 2.);

	glColor4f(1.0, 0.0, 1.0, 1.0);
	cub(10.0, 0.5 ,20.0, 0.25, 0.5, 2.);

	glColor4f(1.0, 1.0, 0.0, 1.0);
	cub(0.0, 0.5 ,0.0, 0.25, 0.5, 2.);


  	// Forzamos la salida por pantalla
	glFlush();
 

	// Nos disponemos a dibujar el subcampo derecho
	// Activamos el back-buffer
	glDrawBuffer (GL_BACK);
    
	// Solo dibujaremos si el valor del pixel en el stencil buffer es igual a 1
	glStencilFunc(GL_EQUAL,1,1);

	// Activamos la matriz de proyecci�n que nos convenga.
	// Es la misma llamada que en el subcampo izquierdo con la �nica diferencia
	// que el argumento del desplazamiento horizontal de la camara (el �ltimo) es positivo

		
	stereoproj(-half_angl_tng*dist* aspect,
				half_angl_tng*dist* aspect,
				-half_angl_tng*dist, half_angl_tng*dist,
				-near_clip_plane, -far_clip_plane,
				-dist, dist, eye);


	// Activamos el z-buffer
	glEnable(GL_DEPTH_TEST);

	// Limpiamos el z-buffer. El buffer de color no lo tenemos que limpiar
	glClearColor(1.0,1.0,1.0,1.0);
	glClear(GL_DEPTH_BUFFER_BIT);
    
	// Situamos la camara
	gluLookAt(1.0, .25, 50-v, 1.0 ,.25 ,49.0-v, 0.0, 1.0, 0.0);

	// Dibujamos el suelo y los cubos
    terra();

    glColor4f(1.0, 0.0, 0.0, 1.0);
	cub(-10.0, 0.5 ,-10.0, 0.25, 0.5, 2.);

	glColor4f(0.0, 1.0, 0.0, 1.0);
	cub(10.0, 0.5 ,-10.0, 0.25, 0.5, 2.);

	glColor4f(0.0, 0.0, 1.0, 1.0);
	cub(-10.0, 0.5 ,20.0, 0.25, 0.5, 2.);

	glColor4f(1.0, 0.0, 1.0, 1.0);
	cub(10.0, 0.5 ,20.0, 0.25, 0.5, 2.);

	glColor4f(1.0, 1.0, 0.0, 1.0);
	cub(0.0, 0.5 ,0.0, 0.25, 0.5, 2.);

	// Forzamos la salida por pantalla
	glFlush();

 
	// Hacemos el swap de los buffers
	glutSwapBuffers();
}


static void key(unsigned char key, int x, int y)
{
  switch (key) {
	case 27:
		exit(0);
		break;

	case 'a':
	    v+=0.5;
		break;
  
	case 'z':
	    v-=0.5;
    break;
  }
}


int main(int ac,char **av)
{
  int i;
  int win;

  WIDTH=640;
  HEIGHT=480;
  
    
  glutInitWindowPosition(0,0);
  glutInitWindowSize(WIDTH,HEIGHT);
  glutInit(&ac,av);

  glutInitDisplayMode(GLUT_RGB|GLUT_DEPTH|GLUT_DOUBLE|GLUT_STENCIL);

  win=glutCreateWindow("EJEMPLO LINE INTERLACED");
    
  // Llamamos al principio a reshape para que ya se cree el patron
  reshape(WIDTH,HEIGHT);

  glutKeyboardFunc(key);
  glutDisplayFunc(display);
  glutIdleFunc(display);
  glutReshapeFunc(reshape);
  glutMainLoop();

  return(0);
}
