/**
 * REDBLUE.C
 *
 * Demo de estereoscopia para gafas de dos colores (red & blue)
 *
 * El objeto se dibuja en rojo para el ojo izquierdo i en azul para el derecho.
 *
 */


#include <stdlib.h>
#include <math.h>
#include <GL/glut.h>

#ifndef PI
#define PI 3.14159265358979323846
#endif

// Variable globales
int w;			// Ancho de la ventana
int h;			// Alto de la ventana
double eye;		// Separaci�n interaxial
double zscreen;	// Plano de parallax = 0
double znear;	// Plano de recorte cercano
double zfar;	// Plano de recorte lejano


const double PIXELS_PER_INCH = 100.0;

void init() {
	GLfloat mat_ambient[] = {0.2,0.0,0.2,1.0} ;
	GLfloat mat_diffuse[] = {0.7,0.0,0.7,1.0} ;
	GLfloat mat_specular[] = {0.1,0.0,0.1,1.0} ;
	GLfloat mat_shininess[]={20.0};

	GLfloat light_position[]={0.0,5.0,20.0,1.0};

	GLfloat light_ambient0[]= {1.0,0.0,0.0,1.0};
	GLfloat light_diffuse0[]= {1.0,0.0,0.0,1.0};
	GLfloat light_specular0[]={1.0,0.0,0.0,1.0};

	GLfloat light_ambient1[]= {0.0,0.0,1.0,1.0};
	GLfloat light_diffuse1[]= {0.0,0.0,1.0,1.0};
	GLfloat light_specular1[]={0.0,0.0,1.0,1.0};

	glDisable(GL_DITHER);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_CULL_FACE);
	glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, 1);


	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient0);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse0);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular0);

	glLightfv(GL_LIGHT1, GL_POSITION, light_position);
	glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient1);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse1);
	glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular1);
	glEnable(GL_LIGHTING);

	eye=0.80;
	zscreen = 10.0;
	znear = 7.0;
	zfar = 13.0;

}

void KeyboardFunc(unsigned char key, int x, int y) {
	
	switch(key) {
		case 27:  /* escape */
		case 'q':
		case 'Q':
			exit(0);
		break;
		case 's': // stereo
			eye = 0.80;
		break;
		case 'm': /* mono */
			eye = 0.0;
		break;
		case 'z':
			eye += 0.1;
		break;
		case 'x':
			eye -= 0.1;
		break;
	}
}

void MenuFunc(int value) {
	KeyboardFunc(value, 0, 0);
}

void IdleFunc(void) {
	glutPostRedisplay();
}

void ReshapeFunc(int w, int h) {
	glViewport(0,0,  w,  h);
	w = w;
	h = h;
}

void DisplayFunc(void) {

	double xfactor=1.0, yfactor=1.0;
	double Eye =0.0;
	int i;
	float left, right, top, bottom;

	if( w < h ) {
		xfactor = 1.0;
		yfactor = h/w;
	}
	else if( h < w ) {
		xfactor = w/h;
		yfactor = 1.0;
	}

	glClear(GL_COLOR_BUFFER_BIT);
	for( i = 0; i < 2 ; i++ ) {
		glEnable(GL_LIGHT0 + i);
		glClear(GL_DEPTH_BUFFER_BIT);
		if( i == 0) { // Ojo izquierdo
			Eye = eye;
			// Creamos una mascara para que solo se pinte el color rojo
			glColorMask(GL_TRUE,GL_FALSE,GL_FALSE,GL_TRUE);
		}
		else { // Ojo derecho
			Eye = -eye;
			// Creamos una mascara para que solo se pinte el color azul
			glColorMask(GL_FALSE,GL_FALSE,GL_TRUE,GL_TRUE);
		}

		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		// Definimos los planos de corte del frustum
		left = (-(w/(2.0*PIXELS_PER_INCH))+Eye) *(znear/zscreen)*xfactor;
		right = (w/(2.0*PIXELS_PER_INCH)+Eye) *(znear/zscreen)*xfactor;
		bottom = -(h/(2.0*PIXELS_PER_INCH))*(znear/zscreen)*yfactor;
		top = (h/(2.0*PIXELS_PER_INCH))*(znear/zscreen)*yfactor;

		// Definimos el frustum
		glFrustum(left, right, bottom, top, znear, zfar);

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glTranslatef(Eye,0.0,0.0);
		glTranslated(0,0,-zscreen);
  
		glPushMatrix();
			glScalef(0.5,0.5,0.5);
			glutSolidDodecahedron();
		glPopMatrix();
		glDisable(GL_LIGHT0 + i);
	}
	glColorMask(GL_TRUE,GL_TRUE,GL_TRUE,GL_TRUE);
	glutSwapBuffers();
}

void VisibilityFunc(int vis) {
	if ( vis == GLUT_VISIBLE ) {
		glutIdleFunc(IdleFunc);
	} else {
	   glutIdleFunc(NULL);
	}
}

int main(int argv, char **argc) {
	glutInit(&argv, argc);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA );
	w = 512;
	h = 512;
	glutInitWindowSize(w, h);
	glutInitWindowPosition(100,100);

	glutCreateWindow("STEREO CON RED & BLUE");
	init();
	glutVisibilityFunc(VisibilityFunc); 
	glutDisplayFunc(DisplayFunc);
	glutReshapeFunc(ReshapeFunc);
	glutKeyboardFunc(KeyboardFunc);
	glutCreateMenu(MenuFunc);
	glutAddMenuEntry("Stereo", 's');
	glutAddMenuEntry("Mono", 'm');
	glutAddMenuEntry("Aumentar disparidad", 'z');
	glutAddMenuEntry("Disminuir disparidad", 'x');
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutMainLoop();
	return 0;
}
